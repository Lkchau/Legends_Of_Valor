public abstract class CharacterAbstractFactory {
        // Abstract factory to get characters
        abstract Character getCharacter(String characterType, String characterName) ;
}
