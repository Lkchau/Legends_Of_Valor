public interface ItemFactoryInterface {

    // Interface for item factorys
    abstract ItemAbstractFactory getItemAbstractFactory(String characterType);
}
