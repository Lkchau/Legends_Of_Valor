//Tile factory interface
public interface TileFactoryInterface {
        abstract Tile getTile(String tileName);
}
