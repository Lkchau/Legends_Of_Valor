public interface Consumable {
    // Idea that an item can be consumed
    abstract void consume(Buffable character);
}
