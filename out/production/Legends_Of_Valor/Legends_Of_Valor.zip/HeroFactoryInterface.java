public interface HeroFactoryInterface {
    // Interface for hero factory
    abstract Hero getHero(String heroType);
}
