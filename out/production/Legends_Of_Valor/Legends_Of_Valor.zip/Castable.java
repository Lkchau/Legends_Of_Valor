public interface Castable {

    // Represent things that can be casted (I.E. skills)
    abstract boolean cast(Character c, Debuffable b);

}
