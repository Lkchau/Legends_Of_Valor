public interface Enterable {
    // idea that something can be entered by a party
    abstract void enter(Character c);
}
