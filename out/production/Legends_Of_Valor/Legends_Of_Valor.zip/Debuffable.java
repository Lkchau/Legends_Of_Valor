public interface Debuffable {
    // Idea that something can be debuffed
    abstract void debuff(Spell s);
}
