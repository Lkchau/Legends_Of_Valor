public interface Game{
    // Abstract idea of a game with instructions and can be ran
    abstract void printInstructions();
    abstract void run();
}
