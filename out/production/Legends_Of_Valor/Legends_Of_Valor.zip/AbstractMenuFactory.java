public abstract class AbstractMenuFactory {
    // Abstract factory for getting menus
    abstract Menu getMenu(String menuName, Party p);
}
