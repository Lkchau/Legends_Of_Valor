public interface MenuFactoryInterface {
    // Interface for the menu factory
    public AbstractMenuFactory getMenu(String menuName);

}
