public interface GameFactoryInterface {
    // Interface for the game factory
    public Game getGame(String gameName);
}
