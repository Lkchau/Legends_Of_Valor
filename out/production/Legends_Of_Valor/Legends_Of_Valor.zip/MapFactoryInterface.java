public interface MapFactoryInterface {
    // Interface for map factory
    abstract Map getMap(String mapType);
}
