public interface Equippable {

    // idea that characters can equip items
    abstract void equip(Character character);
}
