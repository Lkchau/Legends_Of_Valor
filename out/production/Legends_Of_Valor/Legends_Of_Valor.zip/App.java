public class App{
    // Main driver class to run the Legends - Monsters And Heroes game!
    public static void main(String[] args){
        GameManager gm = new GameManager();
        gm.run();
    }
}