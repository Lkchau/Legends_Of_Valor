public interface Buffable {
    // Represent the idea that things can be buffed
    abstract void buff(String stat, int amountToBuff);
}
