public interface Attackable {
    // Interface to represent attackable things (things that can take damage)
    abstract void receiveDamage(Damage damage);
}
